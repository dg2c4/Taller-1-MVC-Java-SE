package controller;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Moto;
import utils.Conexion;

public class MotoDAO {

    private Connection conecta = null;

    public void insertMoto(Moto moto) {
        try {
            if (conecta == null) {
                conecta = Conexion.getConnection();
            }

            String sql = "INSERT INTO moto(id, nombre, marca, anio, precio, tipo, unidades) VALUES (?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement statement = conecta.prepareStatement(sql);
            
            statement.setInt(1, moto.getId());
            statement.setString(2, moto.getNombre());
            statement.setString(3, moto.getMarca());
            statement.setInt(4, moto.getAnio());
            statement.setDouble(5, moto.getPrecio());
            statement.setString(6, moto.getTipo());
            statement.setInt(7, moto.getUnidad());

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "¡El registro fue agregado exitosamente!");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode()
                    + "\nError :" + ex.getMessage());
        }
    }

    public Moto searchMoto(int id) {
        Moto moto = null;
        try {
            if (conecta == null) {
                conecta = Conexion.getConnection();
            }

            String sql = "SELECT * FROM moto WHERE id = ?;";
            PreparedStatement statement = conecta.prepareStatement(sql);
            statement.setInt(1, id);

            ResultSet result = statement.executeQuery();
            if (result.next()) {
                moto = new Moto(result.getInt("id"), result.getString("nombre"), result.getString("marca"),
                        result.getInt("anio"), result.getDouble("precio"), result.getString("tipo"),
                        result.getInt("unidades"));
            } else {
                JOptionPane.showMessageDialog(null, "¡No existe registro!");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode()
                    + "\nError :" + ex.getMessage());
        }

        return moto;
    }

    public void updateMoto(int id, Moto moto) {
        try {
            if (conecta == null) {
                conecta = Conexion.getConnection();
            }

            String sql = "UPDATE moto SET nombre = ?, marca = ?, anio = ?, precio = ?, tipo = ?, unidades = ? WHERE id = ?;";
            PreparedStatement statement = conecta.prepareStatement(sql);
            statement.setString(1, moto.getNombre());
            statement.setString(2, moto.getMarca());
            statement.setInt(3, moto.getAnio());
            statement.setDouble(4, moto.getPrecio());
            statement.setString(5, moto.getTipo());
            statement.setInt(6, moto.getUnidad());
            statement.setInt(7, id);

            int result = statement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Moto actualizada");
            } else {
                JOptionPane.showMessageDialog(null, "Error al actualizar moto");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode()
                    + "\nError :" + ex.getMessage());
        }
    }

    public void deleteMoto(int id) {
        try {
            if (conecta == null) {
                conecta = Conexion.getConnection();
            }

            String sql = "DELETE * FROM moto WHERE id = ?;";
            PreparedStatement statement = conecta.prepareStatement(sql);
            statement.setInt(1, id);

            int result = statement.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(null, "Moto eliminada");
            } else {
                JOptionPane.showMessageDialog(null, "Error al eliminar moto");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Código : " + ex.getErrorCode()
                    + "\nError :" + ex.getMessage());
        }
    }
}