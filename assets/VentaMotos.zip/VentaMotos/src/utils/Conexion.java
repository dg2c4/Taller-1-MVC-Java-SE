/**
 * Fundación Universitaria Konrad Lorenz
 * Desarrollo De Nuesvas Tecnologias
 * Estudiante: David Gutierrez Chaves
 * Código: 506 222 728
 *
 * @author dg2c4
 */
package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {

    public static Connection getConnection() {
        Connection conn = null;

        String host = "localhost";
        String user = "root";
        String password = "@dg2c4;alpha;204";
        String port = "3306";
        String db = "dbmotos";
        String dbURL = "jdbc:mysql://" + host + ":" + port + "/" + db;

        try {
            conn = DriverManager.getConnection(dbURL, user, password);
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }

        return conn;
    }

    public static void main(String[] args) {
        getConnection();
    }
}
