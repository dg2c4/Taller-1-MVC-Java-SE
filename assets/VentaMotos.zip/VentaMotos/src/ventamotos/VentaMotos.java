/**
 * Fundación Universitaria Konrad Lorenz
 * Desarrollo De Nuesvas Tecnologias
 * Estudiante: David Gutierrez Chaves
 * Código: 506 222 728
 * @author dg2c4
 */

package ventamotos;

import static utils.Conexion.getConnection;
import views.FrmNuevoMoto;

public class VentaMotos {

    public static void main(String[] args) {
        FrmNuevoMoto nuevoMoto = new FrmNuevoMoto();
        nuevoMoto.setVisible(true);
    }
}
