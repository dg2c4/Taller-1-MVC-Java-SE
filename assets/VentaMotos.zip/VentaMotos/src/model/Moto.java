/**
 * Fundación Universitaria Konrad Lorenz
 * Desarrollo De Nuesvas Tecnologias
 * Estudiante: David Gutierrez Chaves
 * Código: 506 222 728
 *
 * @author dg2c4
 */
package model;

public class Moto {

    int id;
    String nombre;
    String marca;
    int anio;
    double precio;
    String tipo;
    int unidades;

    public Moto(int id, String nombre, String marca, int anio, double precio, String tipo, int unidades) {
        this.id = id;
        this.nombre = nombre;
        this.marca = marca;
        this.anio = anio;
        this.precio = precio;
        this.tipo = tipo;
        this.unidades = unidades;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidad(int unidades) {
        this.unidades = unidades;
    }
}
